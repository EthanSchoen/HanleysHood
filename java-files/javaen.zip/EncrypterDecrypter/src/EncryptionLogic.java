
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
 * File    : EncryptionLogic
 * Date    : Dec 19, 2011
 * @author   mr Hanley
 * Purpose : Simple encryption/decryption examples
 @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/

public class EncryptionLogic {
    
    /**++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
     *      encryptASCIIOffset(String in, int off)
     * pre:  off is an integer that corresponds to an ASCII offset
     * post: returns a String with the characters offset by off
     * 
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
    
    public String encryptASCIIOffset(String in, int off){
        
        String temp = "";  //This will be our cipherText
        
        int i = 0;
        
        while (i < in.length()) {
            char newChar = in.charAt(i);  //get the ASCII code
            newChar = (char)(newChar + off );
            if (newChar < 0){
                //We offset too low...
                //Let's wrap around to the top
                newChar = (char)(newChar + 255);
            }
            else if (newChar > 255){
                //We offset too high
                newChar = (char)(newChar % 255);
            }
            temp = temp + newChar;
            i++;
        }
        return temp;    
    }
    
    /**++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
     *      writeFile(String fileName, String text)
     * pre:
     * post:  creates or overwrites a file with text called fileName
     * 
    ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
    
    public void writeFile(String fileName, String text){
        try {
            PrintWriter pw = new PrintWriter(fileName);
            
            pw.print(text);
            pw.close();
            
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(EncryptionLogic.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
}
