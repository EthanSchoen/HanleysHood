
/**@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
 * File    : EncryptDecryptApp
 * Date    : Dec 19, 2011
 * @author   mr Hanley
 * Purpose :
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
public class EncryptDecryptApp {

    public static void main(String[] args) {
        EncryptDecryptFrame e = new EncryptDecryptFrame();
        e.setBounds(100, 100, 900, 700);
        e.setTitle("_-_-_-_-Encryption Examples-_-_-_-");
        e.setVisible(true);

    }
}
