/**********************************************
 * <p>Title: Card.java</p>
 *
 * <p>Date: 9/6/08</p>
 * <p>Description: Abstract Card Class</p>
 * <p> Base class for standard playing cards, uno cards, pinochle cards</p>
 * <p>monopoly decks, risk decks, etc.</p>
 * 
 *
 * <p>Copyright: Copyright (c) 2012</p>
 *
 * @author mr Hanley
 * @version 1.0
 ***********************************************/
package org.shenet.hanlchri.multideck;

import java.awt.Image;
import javax.swing.ImageIcon;

public abstract class Card {
    private ImageIcon pict;
    private boolean inPlay;  //true if card is considered not in deck but in some
                            //game pile
    private String description; //"Queen" "Six" etc 
    
    public Card(ImageIcon im, String desc)
    {
        pict = im;
        description = desc;
        inPlay = false;
    }    
    public boolean isInPlay(){
        return inPlay;
    } 
    public String toString() {
        return description;
    }
    public ImageIcon getImage() {
        return pict;
    }
    
    public void setDescription(String desc){
        description = desc;
    }
    public void setInPlay(boolean inp){
        inPlay = inp;
    }
}