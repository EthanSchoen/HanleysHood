package org.shenet.hanlchri.multideck;

import javax.swing.ImageIcon;

public class StandardCard extends Card {
  /*++++++++++++++++++++++++++++++++++++++++++
    I N S T A N C E  V A R I A B L E S

   ++++++++++++++++++++++++++++++++++++++++++*/
  private Suit s;
  private int rank;   //who comes first in games like War, etc
  private int value;  //what it counts in games like blackjack, etc.
  

  /*^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
   C O N S T R U C T O R S

   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^*/
  public StandardCard(Suit su, int ra, int val, ImageIcon im, String desc) {
      super(im,desc);
      s = su;
      rank = ra;
      value = val;
  }
  /*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   A C C E S S O R S

   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/
 
  public String toString() {
      String temp = "";
      
      switch(s){
          case HEARTS:
              temp += " of Hearts\n";
              break;
          case SPADES:
              temp += " of Spades\n";
              break;
          case DIAMONDS:
              temp += " of Diamonds\n";
              break;
          case CLUBS:
              temp += " of Clubs\n";
              break;
          default:  //could be a joker
              temp += "\n";
      }
      return super.toString() + temp;
  }
  /*$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
   M U T A T O R S

   $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$*/




}
