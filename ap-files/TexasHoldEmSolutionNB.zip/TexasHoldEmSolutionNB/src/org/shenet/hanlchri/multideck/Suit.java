/**********************************************
 * <p>Title: Suit.java</p>
 *
 * <p>Date: 9/6/08</p>
 * <p>Description: enum type for suit</p>
 *
 * <p>Copyright: Copyright (c) 2012</p>
 *
 * @author mr Hanley
 * @version 1.0
 ***********************************************/
package org.shenet.hanlchri.multideck;

enum Suit {HEARTS, SPADES, CLUBS, DIAMONDS, NONE};  //NONE for Jokers
