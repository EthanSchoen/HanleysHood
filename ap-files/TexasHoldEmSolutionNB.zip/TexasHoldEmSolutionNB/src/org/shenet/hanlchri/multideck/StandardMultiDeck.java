/**
 * ********************************************
 * <p>Title: StandardMultiDeck.java</p>
 *
 * <p>Date: 9/6/08</p> <p>Description: Represents 1->Many standard decks,
 * shuffled together</p>
 *
 * <p>Copyright: Copyright (c) 2008</p>
 *
 * @author mr Hanley
 * @version 1.0 *********************************************
 */
package org.shenet.hanlchri.multideck;

import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class StandardMultiDeck
        extends MultiDeck {

    public ImageIcon backCardImage; //The back image of a card for hiding
  /*
     * ++++++++++++++++++++++++++++++++++++++++++
     *
     * I N S T A N C E  V A R I A B L E S
     *
     * ++++++++++++++++++++++++++++++++++++++++++
     */
    protected boolean jokersOn; //true if 2 extra jokers are added
   
    /*
     * ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ C O N S T R U C T O R S
     * ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
     */
    /**
     * Creates a 52 card deck, attempts to load in images from disk
     */
    public StandardMultiDeck() {
        try {
            initializeDeck(false); //no jokers by default
        } catch (FileNotFoundException ex) {
            Logger.getLogger(StandardMultiDeck.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     *
     * @param numDecks # of decks requested to be included
     * @param jokers True if 2 jokers per deck are to be added
     */
    public StandardMultiDeck(int numDecks, boolean jokers) {
        super(numDecks);
        try {
            initializeDeck(jokers);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(StandardMultiDeck.class.getName()).log(Level.SEVERE, null, ex);
        }
        shuffle();
    }
    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
    //      A C C E S S O R S
    // 
    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    public ImageIcon getBackCard() {
        return backCardImage;
    }
    
    public boolean hasCard() {
        return numCardsLeft > 0;
    }

    /*
     * $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ M U T A T O R S
     *
     * $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ // /**
     * *************************************************************** private
     * void initializeDeck() pre: numDecks has been initialized post: deck[] is
     * populated with the appropriate cards from 2->Ace per suit
     *
     ****************************************************************
     */
    private void initializeDeck(boolean jokers) throws FileNotFoundException {
        //Let's open up the gif images and load them in
        try {
 System.out.println("(((((((( Initialize Deck");
            //java.net.URL temp = ClassLoader.getSystemResource("images/b2fv.gif"));
            //backCardImage = ImageIO.read(new File("images/b2fv.gif"));
            backCardImage = new ImageIcon(ClassLoader.getSystemResource("images/b2fv.gif"));

            //Load the clubs Ace - 10
    /*
             * for (int i = 1; i <= 10; i++) { String name = "images/c"; name =
             * name + i + ".gif"; cards[0][i] = new
             * ImageIcon(ClassLoader.getSystemResource(name)); } //Load the
             * jack, queen and king cards[0][11] = new
             * ImageIcon(ClassLoader.getSystemResource( "images/cj.gif"));
             * cards[0][12] = new ImageIcon(ClassLoader.getSystemResource(
             * "images/cq.gif")); cards[0][13] = new
             * ImageIcon(ClassLoader.getSystemResource( "images/ck.gif"));
             */

            //Let's decide how many standard decks we will have
            int size = numDecks * 52;
            if (jokers) {
                size += numDecks * 2; //add additional cards for jokers if needed
            }
            numCards = size;

            //Create an array of cards
            deck = new StandardCard[size]; //create a deck of cards

            int next = 0;
            //Loop through the decks
            for (int d = 0; d < numDecks; d++) {

                String descript[] = {"Ace","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten"};
                //Loop through each of the suits
                for (int i = 0; i < 4; i++) {
                    String fileName = "images/";
                    Suit s = null;
                    switch (i) {
                        case 0:
                            s = Suit.HEARTS;
                            fileName += "h";
                            break;
                        case 1:
                            s = Suit.SPADES;
                            fileName += "h";
                            break;
                        case 2:
                            s = Suit.DIAMONDS;
                            fileName += "d";
                            break;
                        case 3:
                            s = Suit.CLUBS;
                            fileName += "c";
                    }
                    //Loop through the ranks
                    String fileNameBefore = fileName;
                    for (int rank = 1; rank <= 10; rank++, next++) {
                        //Assign the 2-10 cards
                        fileName += rank + ".gif";
                        //Image temp = ImageIO.read(new File(fileName));
                        System.out.println("(((((((("+fileName);
                        ImageIcon temp = new ImageIcon(ClassLoader.getSystemResource(fileName));
                        //Instanciate a card and assign the card into the array
                        deck[next] = new StandardCard(s, rank, rank, temp,descript[rank-1] );
                        //Go back to just the suit in the filename
                        fileName = fileNameBefore;
                    }
                    //Now handle the jack, queen and king
                    //Load the jack
                    fileName += "j.gif";
                    ImageIcon temp = new ImageIcon(ClassLoader.getSystemResource(fileName));
                    //ImageIO.read(new File(fileName));
                    deck[next] = new StandardCard(s, 11, 10, temp, "Jack");
                    //Load the queen
                    System.out.println("Got Jack of " + s);
                    next++;
                    fileName = fileNameBefore;
                    fileName += "q.gif";
                    temp = new ImageIcon(ClassLoader.getSystemResource(fileName));
                    deck[next] = new StandardCard(s, 12, 10, temp, "Queen");
                    System.out.println("Got Queen of " + s);
                    //Load the king
                    next++;
                    fileName = fileNameBefore;

                    fileName += "k.gif";
                    temp = new ImageIcon(ClassLoader.getSystemResource(fileName));
                    deck[next] = new StandardCard(s, 13, 10, temp, "King");
                    System.out.println("Got King of " + s);
                    next++;
                }//end loop for each suit

            }
            nextCard = 0; //This is the next card to deal
            numCardsLeft = size;
            nextCard = 0;
        } catch (Exception e) {
            System.out.println("Problem + " + e);
        }
    }
    public boolean returnCard(Card c) {
        return false;
    }
    /**
     * 
     * @return gives you back a Card and you must pass in an integer wrapper to give the Card back
     * @param index use this number to return the Card to the deck
     */
   /* public Card deal(Integer index) {
        return (super.deal(index));
    }  */ 
}
