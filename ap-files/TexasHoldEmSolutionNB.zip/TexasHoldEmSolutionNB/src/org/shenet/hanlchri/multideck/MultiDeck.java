/**
 * ********************************************
 * <p>Title: MultiDeck.java</p>
 *
 * <p>Date: 9/6/08</p> <p>Description: Base Class for many types of card game
 * decks</p>
 *
 * <p>Copyright: Copyright (c) 2008</p>
 *
 * @author mr Hanley
 * @version 1.0 *********************************************
 */
package org.shenet.hanlchri.multideck;

public abstract class MultiDeck implements DeckInterface {
    /*
     * ++++++++++++++++++++++++++++++++++++++++++ I N S T A N C E V A R I A B L
     * E S
     *
     * ++++++++++++++++++++++++++++++++++++++++++
     */

    protected Card[] deck;   //This is the collection of cards to be managed
    protected int numCards;  //reflects the number of cards in the deck
    protected int numDecks;  //can have 1-many decks
    protected int nextCard;  //which card is the next to be dealt
    protected int numCardsLeft;  //how many cards left in deck that are not in play

    /*
     * ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ C O N S T R U C T O R S
     *
     * ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
     */
    public MultiDeck() {
        numDecks = 1;
    }

    public MultiDeck(int numberDecks) {
        numDecks = numberDecks;
    }
    /*
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% A C C E S S O R S
     *
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     */

    /*
     * $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ M U T A T O R S
     *
     * $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
     */
    /**
     *
     */
    public void shuffle() {
        //See if any cards are left
        if (numCardsLeft > 1) {
            for (int i = 0; i < numCards * 7; i++) {
                //Pick a card to swap
                int card1, card2;
                while (true) {
                    card1 = (int) (Math.random() * numCards);
                    if (!deck[card1].isInPlay()) {
                        break;
                    }
                }
                //Pick a 2nd card to swap
                while (true) {
                    card2 = (int) (Math.random() * numCards);
                    if (!deck[card2].isInPlay() && card1 != card2) {
                        break;
                    }
                }
                Card temp = deck[card1];
                deck[card1] = deck[card2];
                deck[card2] = temp;
            }
        }
    }/**
     * 
     * @return gives you back a Card and you must pass in an integer wrapper to give the Card back
     * @param index use this number to return the Card to the deck
     */
    public Card deal(Integer index) {
        if (numCardsLeft > 0) {

            while (deck[nextCard].isInPlay()) {
                nextCard++;
                if (nextCard == deck.length) {
                    nextCard = 0;
                }
            }
            deck[nextCard].setInPlay(true);
            numCardsLeft--;
            return deck[nextCard];
        }
        return null;

    }   
    /**
     *
     * @param c the index of the Card to be returned
     * @return true if Card at c is returned to the deck else it wasn't out in
     * the first place
     */
    public boolean returnCard(int c) {
        if (c < 0 || c >= deck.length) {
            throw new IllegalArgumentException(c + "Out of Range for Deck");
        }
        if (deck[c].isInPlay()) {
            deck[c].setInPlay(false);
            return true;
        }
        return false;
    }
}

