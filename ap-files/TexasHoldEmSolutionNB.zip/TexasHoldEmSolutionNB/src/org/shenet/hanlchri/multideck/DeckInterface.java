/**
 * ********************************************
 * <p>Title: DeckInterface.java</p>
 *
 * <p>Date: 9/6/08</p> <p>Description: Methods every deck must have</p>
 *
 * <p>Copyright: Copyright (c) 2008</p>
 *
 * @author mr Hanley
 * @version 1.0 *********************************************
 */
package org.shenet.hanlchri.multideck;


public interface DeckInterface {

  public abstract Card deal(Integer index);
  public abstract boolean returnCard(int c);
  
  public abstract boolean hasCard();  //true if deck contains additional cards
  public abstract void shuffle();  //shuffles any cards NOT in play,
                                   //cards in play are left 

}