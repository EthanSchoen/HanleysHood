/*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
File:    StringMethods.java
Date:    9/29/08
*        Updated 12/11/2012
Author:  mr. Hanley
Purpose: Logic for String Project, Shenendehowa HS, 
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/

import java.net.URL;
import java.io.BufferedReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.concurrent.atomic.AtomicLong;

public class StringMethods {

    /*****************************************************************
     *     public String pascalsTri(int levels) {
     * pre:  levels >= 3
     * post: returns a String consisting of Pascals' triangle with
     *       \t and \n as appropriate
     * @param levels levels of Pascal's triangle desired
     * @param largest a wrapper with the largest long in the triangle for spacing
     *
     *****************************************************************/
    public String pascalsTri(int levels) {
        return"";
    }

    /*****************************************************************
     *       public int numWords(String word) {
     * pre:
     * post:
     *
     *****************************************************************/
    public int numWords(String word) {
        return 0;
    }

    /*****************************************************************
     *       public String findTitle(String html, String title)
     * pre:
     * post:
     *
     *****************************************************************/
    public String findTitle(String html) {
        return ""; 
    }
     /*****************************************************************
     *       public String findLinks(String html, String title)
     * pre:
     * post:
     *
     *****************************************************************/
    public String[] findLinks(String html) {
        return new String[1];
    }
    /*****************************************************************
     *       public boolean passwordVerify(String text)
     * pre:  pass in pw
     * post: true if len>=6 and one non letter
     *
     *****************************************************************/
    public boolean passwordVerify(String text) {
        return true;
    }
    /*****************************************************************
     *      public String openURL(String url)
     * pre:  pass in a url with http:// in front
     * post: returns the page source if possible
     *
     *****************************************************************/
    public String openURL(String url) throws Exception {
        URL server = null;
        try {
            server = new URL(url); //connect to the target URL
        } catch (MalformedURLException m) {
            throw new Exception(m);
        }

        BufferedReader in = null;
        try {
            in = new BufferedReader(new InputStreamReader(server.openStream())); //open a new stream buffer
        } catch (IOException i) {
            throw new Exception(i);
        }

        String pageSource = "", sourceLine;
        try {
            while ((sourceLine = in.readLine()) != null) { //keep building the string until there is no more to read
                pageSource += sourceLine + "\n";
            }

        } catch (IOException i) {
            throw new Exception(i);
        }

        try {
            in.close(); //close the connection to the server
        } catch (IOException i) {
            throw new Exception(i);
        }
        return pageSource;
    }
}