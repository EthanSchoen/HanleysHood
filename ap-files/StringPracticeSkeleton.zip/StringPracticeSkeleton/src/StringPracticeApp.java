/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Chris
 */
public class StringPracticeApp {
    public static void main(String[] args) {
        StringPractFrame f = new StringPractFrame();
        f.setBounds(150,50,1200,770);
        f.setVisible(true);
        
    }
    
}
